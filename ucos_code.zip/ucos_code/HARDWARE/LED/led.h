#ifndef __LED_H
#define __LED_H

#include "stm32f4xx.h" 
void LED_Init(void);//��ʼ��

#define LED0 PFout(9)
#define LED1 PFout(10)
#define LED2 PEout(13)
#define LED3 PEout(14)

#endif
