#ifndef RTC_H
#define RTC_H

extern OS_FLAG_GRP			g_flag_grp;					//�¼���־��Ķ���

extern void rtc_init(void);
extern void rtc_alarm_set(RTC_AlarmTypeDef RTC_AlarmStructure);
extern void rtc_alarm_a_init(void);
extern void RTC_WKUP_IRQHandler(void);
extern void RTC_Alarm_IRQHandler(void);

/*
//main
	//rtc�ĳ�ʼ��
	rtc_init();
	
//while
	if(g_rtc_wakeup_event)
	{
		
		//��ȡʱ��
		RTC_GetTime(RTC_Format_BCD,&RTC_TimeStructure);
		
		
		//��ȡ����
		RTC_GetDate(RTC_Format_BCD,&RTC_DateStructure);
		//printf��ӡ����ʱ��
		printf("Time=%02X:%02X:%02X %02X\r\n",RTC_TimeStructure.RTC_Hours,RTC_TimeStructure.RTC_Minutes,RTC_TimeStructure.RTC_Seconds,RTC_TimeStructure.RTC_H12);
		printf("Date=20%02X.%02X.%02X %02X\r\n",RTC_DateStructure.RTC_Year,RTC_DateStructure.RTC_Month,RTC_DateStructure.RTC_Date,RTC_DateStructure.RTC_WeekDay);
		
		g_rtc_wakeup_event=0;
	}
//�ж�
	void RTC_WKUP_IRQHandler(void)
	{	

		//����־λ
		if(RTC_GetITStatus(RTC_IT_WUT) == SET)
		{
			//printf("RTC_WKUP_IRQHandler\r\n");
			
			
			g_rtc_wakeup_event=1;
			//printf("%d",g_rtc_wakeup_event);
			//��ձ�־λ
			RTC_ClearITPendingBit(RTC_IT_WUT);
			
			EXTI_ClearITPendingBit(EXTI_Line22);
		}
	}

*/

#endif


