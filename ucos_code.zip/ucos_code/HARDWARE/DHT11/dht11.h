#ifndef RTC_H
#define RTC_H


extern void dht11_init(void);
extern int32_t dht11_read(uint8_t *pbuf);

#endif
