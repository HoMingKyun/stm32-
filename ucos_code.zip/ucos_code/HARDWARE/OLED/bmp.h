#ifndef BMP_H
#define BMP_H
#include "sys.h"

extern const uint8_t pic_alarm[];
extern const uint8_t pic_stay_alarm[];
#endif


