/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                             (c) Copyright 2013; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                           MASTER INCLUDES
*
*                                       IAR Development Kits
*                                              on the
*
*                                    STM32F429II-SK KICKSTART KIT
*
* Filename      : includes.h
* Version       : V1.00
* Programmer(s) : FT
*********************************************************************************************************
*/

#ifndef  INCLUDES_MODULES_PRESENT
#define  INCLUDES_MODULES_PRESENT


/*
*********************************************************************************************************
*                                         STANDARD LIBRARIES
*********************************************************************************************************
*/


#include  <stdio.h>
#include  <string.h>
#include  <ctype.h>
#include  <stdlib.h>
#include  <stdarg.h>
#include  <math.h>


/*
*********************************************************************************************************
*                                                 OS
*********************************************************************************************************
*/

#include  <os.h>


/*
*********************************************************************************************************
*                                              LIBRARIES
*********************************************************************************************************
*/

#include  <cpu.h>
#include  <lib_def.h>
#include  <lib_ascii.h>
#include  <lib_math.h>
#include  <lib_mem.h>
#include  <lib_str.h>

/*
*********************************************************************************************************
*                                              APP / BSP
*********************************************************************************************************
*/

#include  <app_cfg.h>
#include  <bsp.h>
//#include  <bsp_int.h>


//�¼���־�飺Ӳ��ʹ�õ��ı�־λ
#define FLAG_GRP_RTC_WAKEUP					0x01
#define FLAG_GRP_RTC_ALARM_A				0x02

#define FLAG_KEY0							0x11
#define FLAG_KEY2							0x12
#define FLAG_KEY3							0x14
#define FLAG_KEY4							0x18

extern OS_FLAG_GRP				g_flag_grp;			//�¼���־��Ķ���
extern OS_FLAG_GRP				g_flag_key;

extern OS_Q					g_queue_usart1;		//��Ϣ���еĶ���
extern OS_Q					g_queue_led;
extern OS_Q					g_queue_beep;
extern OS_Q					g_queue_dht11;
extern OS_Q					g_queue_ir;

extern OS_MUTEX				g_mutex_printf;		//�������Ķ���
extern OS_MUTEX				g_mutex_oled;		

extern OS_SEM					g_sem_led;			//�ź����Ķ���
extern OS_SEM					g_sem_beep;

extern OS_TCB app_task_tcb_rtc;
extern OS_TCB app_task_tcb_rtc_alarm;
extern OS_TCB app_task_tcb_led;
extern OS_TCB app_task_tcb_beep;

#endif
